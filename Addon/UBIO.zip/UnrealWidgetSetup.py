import bpy

#TODO: 根据UI输入找到UE路径， 复制 WidgetBP和Python脚本到UE工程下的Content/UBIO

