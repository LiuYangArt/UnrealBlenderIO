download

https://github.com/LiuYangArt/UnrealBlenderIO/blob/main/Addon/UBIO.zip


TODO:
 - 一键配置UE端的脚本